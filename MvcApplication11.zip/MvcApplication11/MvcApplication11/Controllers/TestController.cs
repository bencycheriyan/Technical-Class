﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MvcApplication11.Models;

namespace MvcApplication11.Controllers
{
    public class TestController : Controller
    {
        //
        // GET: /Test/

        public ActionResult Index()
        {
            return View();
        }

         public ActionResult getString()
        {
            return View();
        }


        public ActionResult student()
        {    

        student s = new student();
        s.Sname = "amaljyothi";
        s.Semail = "amal jyothiii";
            return View(s);
        }





    }
}
