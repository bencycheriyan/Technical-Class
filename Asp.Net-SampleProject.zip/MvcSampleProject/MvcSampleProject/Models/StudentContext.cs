﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.Entity;

namespace MvcSampleProject.Models
{
    public class StudentContext:DbContext
    {
        
        public StudentContext()
            :base("con")
        {
            DropCreateDatabaseIfModelChanges<StudentContext> d = new DropCreateDatabaseIfModelChanges<StudentContext>();
            Database.SetInitializer<StudentContext>(d);
        }

        public DbSet<Registration> Registrations { get; set; }

        public DbSet<Department> Departments { get; set; }
    }
}