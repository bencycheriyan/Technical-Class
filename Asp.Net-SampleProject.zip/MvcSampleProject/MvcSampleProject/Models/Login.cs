﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace MvcSampleProject.Models
{
    public class Login
    {
        [Required]
        public String Uname { get; set; }
        [Required]
        [DataType(DataType.Password)]
        public String Pwd { get; set; }
    }
}