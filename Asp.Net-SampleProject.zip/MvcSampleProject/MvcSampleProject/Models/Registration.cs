﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;




namespace MvcSampleProject.Models
{
    public class Registration
    {
        public int RegistrationId { get; set; }
        [Required]
        [Display(Name = "Username")]
        public String username { get; set; }
        [Required]
        [DataType(DataType.Password)]
        public String password { get; set; }
        [Required]
        [Display(Name = "Enter Name")]
        public String name { get; set; }
        [Required]
        [DataType(DataType.MultilineText)]
        [Display(Name = "Address")]
        public String address { get; set; }
        [Required]
        [DataType(DataType.EmailAddress,ErrorMessage="invalid")]
        public String email { get; set; }
        public Gender Genderlist { get; set; }

    }
    public enum Gender
    {
        Male,
        Female
    }
}