﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(aspprogram1.Startup))]
namespace aspprogram1
{
    public partial class Startup {
        public void Configuration(IAppBuilder app) {
            ConfigureAuth(app);
        }
    }
}
