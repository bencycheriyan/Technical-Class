<?php
if(isset($_GET["reg_id"]))
{
require 'db.php';
$reg_id = $_GET['reg_id'];
$result = mysqli_query($mysqli, "DELETE FROM users WHERE id=$id");
?>