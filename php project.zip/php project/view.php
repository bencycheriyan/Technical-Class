<?php
require 'db.php';
$sq1="select * from register";
$res=mysqli_query($con,$sq1);
if (mysqli_num_rows($res))
{
    echo
        '<center> <table border=1>
        <tr> <td>Name</td>
        <td>Age</td>
        <td>Address</td>
		<td>Update</td>
        </tr>';
        while ($row=  mysqli_fetch_array($res)){
          echo'
              <tr> <td>'.$row['name'].'</td>
         <td>'.$row['age'].'</td>
         <td>'.$row['address'].'</td>
		 <td><a href="edit.php"><u>Edit</u></a></td>
		 <td><a href="delete.php"><u>Delete</u></a></td>
        </tr>';   
        }
		
     echo'</table>';
	 
	 
}
?>