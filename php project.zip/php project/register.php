<?php
require 'db.php';
if(isset($_POST["Submit"]))
{
	
	$t1=$_POST["name"];
	$t2=$_POST["age"];
	$t3=$_POST["address"];
	
$sql="insert into `register`(`name`,`age`,`address`)values('$t1','$t2','$t3')";
$result=mysqli_query($con,$sql);

}
?>
<html>
<title>Registration</title>
<body>
<h1>Registration</h1>
<form action="#" method="POST">
  Name:
  <input type="text" name="name" required >
  <br><br>
  Age:
  <input type="number" name="age" required >
  <br><br>
  Address:
  <input type="text" name="address" required >
  <br><br>
  <input type="submit" name="Submit" value="Save">
   <a href="view.php"><font size="3"  color="#040a5e"><u>view users</u></font></a>
  </form>
  </body>
  </html>