	 <?php
 
require 'db.php';
$id=$_GET['q'];
echo $id;
$s="select * from register where reg_id=$id";
$result=mysqli_query($con,$s);
$w=mysqli_fetch_array($result);
	  ?>
	  <table border=0>
	  <tr><th class="form-control">Name</th><td><input type="text" class="form-control" name="name" value="<?php echo $w['name'];?>"/></td></tr>
<tr><th class="form-control">Age </th><td><input type="text" class="form-control" name="age" value="<?php echo $w['age'];?>"/></td></tr>
<tr><th class="form-control">address</th><td><input type="text" class="form-control" name="address" value="<?php echo $w['address'];?>"/></td></tr>
<tr><th><input type="submit" name="submit" value="update"/></th></tr>
</table>