﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MvcApplication22.Models;

namespace MvcApplication22.Controllers
{
    public class StudController : Controller
    {
        private UserDemoContext db = new UserDemoContext();

        //
        // GET: /Stud/

        public ActionResult Index()
        {
            var class1 = db.Class1.Include(c => c.userdemo);
            return View(class1.ToList());
        }

        //
        // GET: /Stud/Details/5

        public ActionResult Details(int id = 0)
        {
            Class1 class1 = db.Class1.Find(id);
            if (class1 == null)
            {
                return HttpNotFound();
            }
            return View(class1);
        }

        //
        // GET: /Stud/Create

        public ActionResult Create()
        {
            ViewBag.UserDemoId = new SelectList(db.userdemo, "UserDemoId", "name");
            return View();
        }

        //
        // POST: /Stud/Create

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(Class1 class1)
        {
            if (ModelState.IsValid)
            {
                db.Class1.Add(class1);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            ViewBag.UserDemoId = new SelectList(db.userdemo, "UserDemoId", "name", class1.UserDemoId);
            return View(class1);
        }

        //
        // GET: /Stud/Edit/5

        public ActionResult Edit(int id = 0)
        {
            Class1 class1 = db.Class1.Find(id);
            if (class1 == null)
            {
                return HttpNotFound();
            }
            ViewBag.UserDemoId = new SelectList(db.userdemo, "UserDemoId", "name", class1.UserDemoId);
            return View(class1);
        }

        //
        // POST: /Stud/Edit/5

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(Class1 class1)
        {
            if (ModelState.IsValid)
            {
                db.Entry(class1).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.UserDemoId = new SelectList(db.userdemo, "UserDemoId", "name", class1.UserDemoId);
            return View(class1);
        }

        //
        // GET: /Stud/Delete/5

        public ActionResult Delete(int id = 0)
        {
            Class1 class1 = db.Class1.Find(id);
            if (class1 == null)
            {
                return HttpNotFound();
            }
            return View(class1);
        }

        //
        // POST: /Stud/Delete/5

        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            Class1 class1 = db.Class1.Find(id);
            db.Class1.Remove(class1);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            db.Dispose();
            base.Dispose(disposing);
        }
    }
}