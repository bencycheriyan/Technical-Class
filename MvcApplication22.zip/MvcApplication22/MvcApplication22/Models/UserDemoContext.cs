﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.Entity;
namespace MvcApplication22.Models
{
    public class UserDemoContext:DbContext
    {
        public UserDemoContext(): base("mycon")
        {
            DropCreateDatabaseIfModelChanges<UserDemoContext> d = new DropCreateDatabaseIfModelChanges<UserDemoContext>();
            Database.SetInitializer(d);
        }
        public DbSet<UserDemo> userdemo { get; set; }

        public DbSet<Class1> Class1 { get; set; }
    }
}