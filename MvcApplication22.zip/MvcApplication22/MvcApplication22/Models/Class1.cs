﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MvcApplication22.Models
{
    public class Class1
    {
        public int Class1Id { get; set; }
        public int UserDemoId { get; set; }
        public virtual UserDemo userdemo { get; set; }

        public String Sname { get; set; }
        public String Semail { get; set; }
        public Gender Genderlist { get; set; }

    }
    public enum Gender
    {
        Male,
        Female
    }
}